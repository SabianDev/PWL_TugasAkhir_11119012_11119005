
<?php
$swnip=$_POST['nip'];
$swnama=$_POST['nama'];
$swgender=$_POST['gender'];
$swmatpel=$_POST['matpel'];
$swemail=$_POST['email'];
$swnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="insert into tb_guru(gr_nip,gr_nama,gr_gender,gr_matpel,gr_email,gr_notelp) values(
	'$swnip',
	'$swnama',
	'$swgender',
	'$swmatpel',
	'$swemail',
	'$swnotelp')";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=guru&pesan=berhasil_tambah");
	
}else{
	header("location:../index.php?hal=guru&pesan=gagal_tambah");
	echo mysqli_error();
	echo "$sql";
}


