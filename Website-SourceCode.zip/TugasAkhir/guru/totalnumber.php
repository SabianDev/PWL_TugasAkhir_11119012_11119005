
<?php
include "koneksi.php";
$query = "SELECT * FROM tb_guru";
$gururesult = mysqli_query($mysqli,$query);
if ($gururesult)
    {
        // it return number of rows in the table.
        $totalguru = mysqli_num_rows($gururesult);
        //how to print
        //printf($totalguru);

    }
?>