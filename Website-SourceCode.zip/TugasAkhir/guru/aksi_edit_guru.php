
<?php
$grnip=$_POST['nip'];
$grnama=$_POST['nama'];
$grgender=$_POST['gender'];
$grmatpel=$_POST['matpel'];
$gremail=$_POST['email'];
$grnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="update tb_guru set gr_nama='$grnama',gr_gender='$grgender',gr_matpel='$grmatpel',gr_email='$gremail',gr_notelp='$grnotelp' where gr_nip='$grnip'";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=guru&pesan=berhasil_edit");
}else{
	header("location:../index.php?hal=guru&pesan=gagal_edit");
	echo mysqli_error();
	echo "$sql";
}


