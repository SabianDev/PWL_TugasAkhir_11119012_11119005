<?php
    //kode dijalankan ketika ada user yg akses login.php tanpa login dulu
    session_start();
    if (isset($_SESSION['username'])){
        header("Location: index.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="stylelogin.css">
        <title>Login</title>
    </head>
    <body>
           
        <div class="wrapper fadeInDown">
            <h1 style="color: #fff; ">Selamat Datang</h1>
            <div id="formContent">
              <!-- Tabs Titles -->
              <h2 class="active"> Sign In </h2>
                
              <!-- Icon -->
              <div class="fadeIn first">
                <br> 
                    <img src="dist/img/smklogo.png"id="icon" alt="User Icon"/>
                <br><br>
              </div>
          
              <!-- Login Form -->
              <form name="f1" action = "authentication.php" onsubmit = "return validation()" method = "POST">
                    <!--Username-->
                <input type="text" id="login" class="fadeIn second" name="user" id="user" placeholder="username">
                    <!--Password-->
                <input type="password" id="password" class="fadeIn third" name="pass" id="pass" placeholder="password">
                    <!--Login Button-->
                <input type="submit" class="fadeIn fourth" name="btn" id="btn" value="Log In">
              </form>
          
            </div>
          </div>
        <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("Username dan Password kosong, silahkan coba lagi."); 
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("Username kosong, silahkan coba lagi.");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password kosong, silahkan coba lagi.");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
    </body>
</html>