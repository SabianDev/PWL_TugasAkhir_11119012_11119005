
<div class="content-wrapper" style="min-height: 956px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        EDIT DATA SISWA
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>
    
<?php
include ("koneksi.php");
$sql="SELECT * FROM tb_siswa WHERE sw_nis='$_GET[id]' ";
$query=mysqli_query($mysqli, $sql);
$row=mysqli_fetch_array($query);
?>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form edit data siswa</h3>

              

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="siswa/aksi_edit_siswa.php" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label>Nama</label>
                  <input type="text" class="form-control" placeholder="Masukkan Nama" name="nama" value="<?php echo $row['sw_nama'];?>">
                </div>
                <div class="form-group">
                  <label>Jenis Kelamin</label>
                  <select name="gender" class="form-control">
                  	<option value="Pria" <?php echo $row['sw_gender']=='Pria'? 'selected':'';?>>
                  		Pria
                  	</option>
                  	<option value="Wanita" <?php echo $row['sw_gender']=='Wanita'? 'selected':'';?>>
                  		Wanita
                  	</option>
                  </select>
                </div>
                <div class="form-group">
                	<label>Alamat</label>
                	<textarea class="form-control" name="alamat"><?php echo $row['sw_alamat'];?></textarea>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" placeholder="Masukkan Email" name="email" value="<?php echo $row['sw_email'];?>">
                </div>
                <div class="form-group">
                	<label>No. HP</label>
                	<input class="form-control" name="notelp" type="number" value="<?php echo $row['sw_notelp'];?>">
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <input type="hidden" name="nis" value="<?php echo $row['sw_nis'];?>">
                 <button type="submit" class="btn btn-primary">Ubah</button>
               </div>
              
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>