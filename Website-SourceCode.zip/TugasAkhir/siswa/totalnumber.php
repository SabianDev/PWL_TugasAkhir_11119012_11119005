
<?php
include "koneksi.php";
$query = "SELECT * FROM tb_siswa";
$siswaresult = mysqli_query($mysqli,$query);
if ($siswaresult)
    {
        // it return number of rows in the table.
        $totalsiswa = mysqli_num_rows($siswaresult);
        //how to print
        //printf($totalsiswa);

    }
?>