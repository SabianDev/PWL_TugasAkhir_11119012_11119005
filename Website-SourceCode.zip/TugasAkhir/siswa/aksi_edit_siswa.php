
<?php
$swnis=$_POST['nis'];
$swnama=$_POST['nama'];
$swgender=$_POST['gender'];
$swalamat=$_POST['alamat'];
$swemail=$_POST['email'];
$swnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="update tb_siswa set sw_nama='$swnama',sw_gender='$swgender',sw_alamat='$swalamat',sw_email='$swemail',sw_notelp='$swnotelp' where sw_nis='$swnis'";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=siswa&pesan=berhasil_edit");
}else{
	header("location:../index.php?hal=siswa&pesan=gagal_edit");
	echo mysqli_error();
	echo "$sql";
}


