
<?php
$swnis=$_POST['nis'];
$swnama=$_POST['nama'];
$swgender=$_POST['gender'];
$swalamat=$_POST['alamat'];
$swemail=$_POST['email'];
$swnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="insert into tb_siswa(sw_nis,sw_nama,sw_gender,sw_alamat,sw_email,sw_notelp) values(
	'$swnis',
	'$swnama',
	'$swgender',
	'$swalamat',
	'$swemail',
	'$swnotelp')";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=siswa&pesan=berhasil_tambah");
	
}else{
	header("location:../index.php?hal=siswa&pesan=gagal_tambah");
	echo mysqli_error();
	echo "$sql";
}


