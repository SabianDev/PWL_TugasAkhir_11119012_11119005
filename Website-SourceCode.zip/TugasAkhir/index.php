<?php

//kode dijalankan ketika ada user yg akses index.php tanpa login dulu
session_start();
if (!isset($_SESSION['username'])){
  header("Location: login.php"); 
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>SMK Bestari Data Management</title>
  </head>
<body class="hold-transition skin-green sidebar-mini">
<?php include "style/pilih_style.php";?>
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b><img src="dist/img/smklogowhite.png"id="icon" width="50" height="50" alt="User Icon"/></b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>SMK</b>BESTARI</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          
          <!-- Notifications: style can be found in dropdown.less -->
          
          <!-- Tasks: style can be found in dropdown.less -->
          
          <!-- User Account: style can be found in dropdown.less -->
          <!--user details-->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/profile-user.png" class="user-image" alt="User Image">
              <span class="hidden-xs">

              <?php echo $_SESSION['username'];?>

              </span>
              
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/profile-user.png" class="img-circle" alt="User Image">
              <!-- Username -->
                <p>
                  <?php echo $_SESSION['username'];?>
                  <small>Level</small>
                </p>
              </li>
              
              <!-- Menu Footer-->
              <li class="user-footer"><p align="center">
                  <a href="action-logout.php" class="btn btn-default btn-flat ">Log out</a>
              </p></li>

            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <?php
    include "menu.php";
  ?>

  <!-- Content Wrapper. Contains page content -->
  <?php
    include "content.php";
  ?>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="https://adminlte.io">AdminLTE</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark" style="display: none;">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">ABOUT</h3>
        <ul class="control-sidebar-menu">
          
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">ANGGOTA KELOMPOK</h4>

                <p>(11119012) Reyhan Sabian</p>
                <p>(11119005) Rangga Umar Pratama</p>
              </div>
            </a>
          </li>
          
        <!-- /.control-sidebar-menu -->

        
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php
include "js/pilih_js.php";
?>
</body>
</html>
