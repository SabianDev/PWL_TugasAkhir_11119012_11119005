<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <!--foto pp-->
        <div class="pull-left image">
          <img src="dist/img/profile-user.png" class="img-circle" alt="User Image">
        </div>
        <!--nama user-->
        <div class="pull-left info">
          <small>Masuk sebagai :</small>
          <p>
            <?php echo $_SESSION['username'];?>
          </p>
        </div><br>
      </div>
            <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">        
        
        <li>
          <a href="index.php?hal=home">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

        <li>
          <a href="index.php?hal=siswa">
            <i class="fa fa-users"></i> <span>Siswa</span>
          </a>
        </li>
        <li>
          <a href="index.php?hal=guru">
            <i class="fa fa-users"></i> <span>Guru</span>
          </a>
        </li>
        <li>
          <a href="index.php?hal=petugas">
            <i class="fa fa-users"></i> <span>Petugas</span>
          </a>
        </li>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>