<?php
    if (isset($_GET['hal'])) {
        //Siswa
        if ($_GET['hal']=='siswa') {
          include "siswa/siswa.php";
        }
        elseif ($_GET['hal']=='tambah_siswa') {
          include "siswa/tambah_siswa.php";
        }
        elseif ($_GET['hal']=='edit_siswa') {
          include "siswa/edit_siswa.php";
        }

        //Guru
        elseif ($_GET['hal']=='guru') {
          include "guru/guru.php";
        }
        elseif ($_GET['hal']=='tambah_guru') {
          include "guru/tambah_guru.php";
        }
        elseif ($_GET['hal']=='edit_guru') {
          include "guru/edit_guru.php";
        }

        //Petugas
        elseif ($_GET['hal']=='petugas') {
          include "petugas/petugas.php";
        }
        elseif ($_GET['hal']=='tambah_petugas') {
          include "petugas/tambah_petugas.php";
        }
        elseif ($_GET['hal']=='edit_petugas') {
          include "petugas/edit_petugas.php";
        }

        else
        {
          include "home.php";
        }
    }else{
    include "home.php";
    }
?>