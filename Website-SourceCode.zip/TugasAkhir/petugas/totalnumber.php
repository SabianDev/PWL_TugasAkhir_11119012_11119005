
<?php
include "koneksi.php";
$query = "SELECT * FROM tb_user";
$userresult = mysqli_query($mysqli,$query);
if ($userresult)
    {
        // it return number of rows in the table.
        $totaluser = mysqli_num_rows($userresult);
        //how to print
        //printf($totaluser);

    }
?>