<?php
$ptid=$_POST['id'];
$ptnama=$_POST['nama'];
$ptgender=$_POST['gender'];
$ptlevel=$_POST['level'];
$ptemail=$_POST['email'];
$ptnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="update tb_user set pt_nama='$ptnama',pt_gender='$ptgender',pt_level='$ptlevel',pt_email='$ptemail',pt_notelp='$ptnotelp' where id='$ptid'";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=petugas&pesan=berhasil_edit");
}else{
	header("location:../index.php?hal=petugas&pesan=gagal_edit");
	echo mysqli_error();
	echo "$sql";
}


