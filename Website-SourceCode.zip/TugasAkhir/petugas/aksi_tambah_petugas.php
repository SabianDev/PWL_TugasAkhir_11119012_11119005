<?php
$id=$_POST['id'];
$ptnama=$_POST['nama'];
$username=$_POST['username'];
$password=$_POST['password'];
$ptgender=$_POST['gender'];
$ptlevel=$_POST['level'];
$ptemail=$_POST['email'];
$ptnotelp=$_POST['notelp'];

include("../koneksi.php");

$sql="insert into tb_user(id,username,password,pt_nama,pt_gender,pt_level,pt_email,pt_notelp) values(
	'$id',
	'$username',
	'$password',
	'$ptnama',
	'$ptgender',
	'$ptlevel',
	'$ptemail',
	'$ptnotelp')";

$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=petugas&pesan=berhasil_tambah");
	
}else{
	header("location:../index.php?hal=petugas&pesan=gagal_tambah");
	echo mysqli_error();
	echo "$sql";
}


