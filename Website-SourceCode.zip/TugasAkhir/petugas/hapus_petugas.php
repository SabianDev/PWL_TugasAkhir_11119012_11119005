<?php
include("../koneksi.php");
$sql="delete from tb_user where id='$_GET[id]'";
$query=mysqli_query($mysqli,$sql);
if ($query) {
	header("location:../index.php?hal=petugas&pesan=berhasil_hapus");
}else{
	header("location:../index.php?hal=petugas&pesan=gagal_hapus");
	echo mysqli_error();
	echo "$sql";
}
?>