<?php
    //kode dijalankan ketika ada user yg akses index.php tanpa login dulu
    session_start();
    if (isset($_SESSION['username'])){
        header("Location: index.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
           
        <div class="wrapper fadeInDown">
            <h1 style="color: #fff; ">Selamat Datang</h1>
            <div id="formContent">
              <!-- Tabs Titles -->
              <h2 class="active"> Sign In </h2>
                
              <!-- Icon -->
              <div class="fadeIn first">
                <br> 
                <img src="https://api.iconify.design/codicon-account.svg" width="200" height="200" id="icon" alt="User Icon"/>
                <br><br>
              </div>
          
              <!-- Login Form -->
              <form name="f1" action = "authentication.php" onsubmit = "return validation()" method = "POST">
                    <!--Username-->
                <input type="text" id="login" class="fadeIn second" name="user" id="user" placeholder="username">
                    <!--Password-->
                <input type="password" id="password" class="fadeIn third" name="pass" id="pass" placeholder="password">
                    <!--Login Button-->
                <input type="submit" class="fadeIn fourth" name="btn" id="btn" value="Log In">
              </form>
          
            </div>
          </div>
        <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("Username and Password is empty"); 
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
    </body>
</html>


<!-- Kode Backup jika ada yg salah
<html>  
<head>  
    <title>PHP login system</title>  
    <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>  
<body>  
    <div id = "frm">  
        <h1>Login</h1>  
        <form name="f1" action = "authentication.php" onsubmit = "return validation()" method = "POST">  
            <p>  
                <label> UserName: </label>  
                <input type = "text" id="user" name="user" />  
            </p>  
            <p>  
                <label> Password: </label>  
                <input type = "password" id="pass" name="pass" />  
            </p>  
            <p>     
                <input type =  "submit" id = "btn" value = "Login" />  
            </p>  
        </form>  
    </div>  
    
    //validasi kalau kosong
    <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("Username and Password is empty"); 
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
</body>     
</html>  
-->