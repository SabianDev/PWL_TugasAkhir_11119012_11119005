
<?php
    //kode dijalankan ketika ada user yg akses index.php tanpa login dulu
    session_start();
    if (!isset($_SESSION['username'])){
       header("Location: teslogin.php"); 
    }
?>

<html>
    <head>
        <title>
            Halaman Index
        </title>
    </head>
    <h1>Halaman Index yang jelek</h1>
    <a href=action-logout.php>
        <button>hayu kita logout</button>
    </a>
</html>