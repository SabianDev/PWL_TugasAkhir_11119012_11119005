<html>
    <head>
        <title>
            Halaman Kalau belum login
        </title>
    </head>
    <h1>Halaman Kalau Belum Login</h1>
    <a href="/TugasAkhir/login/teslogin.php">
    <button>Login Dulu</button>
    </a>
</html>