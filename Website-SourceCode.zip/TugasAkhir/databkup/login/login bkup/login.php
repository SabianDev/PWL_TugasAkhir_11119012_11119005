<?php
require 'functions.php';

if( isset($_POST["login"])){
  $username = $_POST["username"];
  $password = $_POST["password"];

  $result = mysqli_query($conn, "SELECT * FROM tb_petugas WHERE pt_username = '$username'");

  //check username
  if( mysqli_num_rows($result) === 1 ){
    //check pass
    $row = mysqli_fetch_assoc($result);
    if (password_verify($password, $row["password"])) {
      header ("Location: index.php");
      exit;
    }
  }
}

?>

<html>
    <head>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
           
        <div class="wrapper fadeInDown">
            <h1 style="color: #fff;">Selamat Datang di Dashboard</h1>
            <div id="formContent">
              <!-- Tabs Titles -->
              <h2 class="active"> Sign In </h2>
                
              <!-- Icon -->
              <div class="fadeIn first">
                <br> 
                <img src="https://api.iconify.design/codicon-account.svg" width="200" height="200" id="icon" alt="User Icon"/>
                <br><br>
              </div>
          
              <!-- Login Form -->
              <form action="" method="post">
                <input type="text" id="login" class="fadeIn second" name="username" id="username" placeholder="username">
                <input type="password" id="password" class="fadeIn third" name="password" id="password" placeholder="password">
                <input type="submit" class="fadeIn fourth" name="login" value="Log In">
              </form>
          
            </div>
          </div>
       
    </body>
</html>