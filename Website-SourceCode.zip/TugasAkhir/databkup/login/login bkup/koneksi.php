<?php
$mysqli=mysqli_connect("localhost", "root", "", "test_dbsiswa");
mysqli_select_db($mysqli,"test_dbsiswa") or die("Gagal koneksi ke DB");
?>