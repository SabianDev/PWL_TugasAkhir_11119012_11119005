<?php
require 'functions.php';

if (isset($_POST ["register"])){
  if (registrasi($_POST)>0){
    echo "<script>
    alert('User berhasil ditambahkan!');
    </script>";
  } else {
    echo mysqli_error($conn);
  }
}

?>
<html>
    <head>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
           
        <div class="wrapper fadeInDown">
            <h1 style="color: #fff;">Selamat Datang di Dashboard</h1>
            <div id="formContent">
              <!-- Tabs Titles -->
              <h2 class="active"> Registrasi </h2>
              
          
              <!-- Login Form -->
              <form action="" method="post">
                <input type="text" id="login" class="fadeIn second" name="username" id="username" placeholder="username">
                <input type="password" id="password" class="fadeIn third" name="password" id="password" placeholder="password">
                <input type="password" id="conpassword" class="fadeIn third" name="conpassword" id="conpassword" placeholder="confirm password">
                <input type="submit" class="fadeIn fourth" name="register" value="Register">
              </form>
          
          
            </div>
          </div>
       
    </body>
</html>