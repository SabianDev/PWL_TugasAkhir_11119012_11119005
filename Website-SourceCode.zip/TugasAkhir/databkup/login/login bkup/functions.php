<?php
$conn=mysqli_connect("localhost", "root", "", "test_dbsiswa");
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

function registrasi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $conpassword = mysqli_real_escape_string($conn, $data["conpassword"]);

    //cek duplicate user
    $result = mysqli_query($conn, "SELECT username FROM tb_petugas WHERE username = '$username'");
    if(mysqli_fetch_assoc($result)){
        echo "<script>
            alert('username sudah terdaftar.')
        </script>";
        return false;
    }

    //cek confirm pass
    if( $password !== $conpassword){
        echo "<script>
        alert('Konfirmasi password tidak sesuai. Mohon cek ulang.')
        </script>";
        return false;
    }}


//enkripsi pass

$password = password_hash($password, PASSWORD_DEFAULT);



//insert to database
mysqli_query($conn, "INSERT INTO tb_petugas VALUES('', '$username', '$password')");
return mysqli_affected_rows($conn); 