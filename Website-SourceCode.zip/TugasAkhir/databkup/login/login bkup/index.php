<html>
    <header>
        <title>Halaman INDEX</title>
    </header>
    <body>
        <h1>Ini adalah halaman awal</h1>
        e
    </body>
</html>