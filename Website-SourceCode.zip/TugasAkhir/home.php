

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Home
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard active"></i> Home</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <h1><b>Selamat datang di Website Data Managemen SMK BESTARI</b></h1>
      <br><br><br>
      <h3><b>Data terkini :</b></h3>

      <!--DISPLAY SISWA -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>
                <?php
                  include "siswa/totalnumber.php";
                  printf($totalsiswa);
                ?>
                
              </h3>

              <p>Siswa</p>
            </div>
            <div class="icon">
              <i class="ion ion-person"></i>
            </div>
            <a href="index.php?hal=siswa" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

        <!--DISPLAY GURU -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>

              <?php
                  include "guru/totalnumber.php";
                  printf($totalguru);
                ?>

              </h3>

              <p>Guru</p>
            </div>
            <div class="icon">
              <i class="ion ion-person"></i>
            </div>
            <a href="index.php?hal=guru" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>

              <?php
                  include "petugas/totalnumber.php";
                  printf($totaluser);
                ?>

              </h3>

              <p>Petugas</p>
            </div>
            <div class="icon">
              <i class="ion ion-person"></i>
            </div>
            <a href="index.php?hal=petugas" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <!-- ./col -->
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <h4><b>Deskripsi Program :</b></h4>
      <p>
        Website Managemen Data Sekolah ini memiliki fungsi untuk mengatur database sebuah sekolah, mulai dari<br>
        data siswa, data guru, hingga data petugas.
      </p>
      <br><br>
      <h4><b>Anggota Kelompok :</b></h4>
      <ul>
        <li>(11119012) Reyhan Sabian</li>
        <li>(11119005) Rangga Umar Pratama</li>
      </ul>
      <!-- Main row -->
      
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>