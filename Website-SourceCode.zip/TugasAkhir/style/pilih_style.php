<?php
    if (isset($_GET['hal'])) {
        //siswa
        if ($_GET['hal']=='siswa') {
          include "style/style_tabel.php";
        }
        elseif ($_GET['hal']=='tambah_siswa') {
          include "style/style2.php";
        }
        elseif ($_GET['hal']=='edit_siswa') {
          include "style/style2.php";
        }


        //guru
        elseif ($_GET['hal']=='guru') {
          include "style/style_tabel.php";
        }
        elseif ($_GET['hal']=='tambah_guru') {
          include "style/style2.php";
        }
        elseif ($_GET['hal']=='edit_guru') {
          include "style/style2.php";
        }

        //petugas
        elseif ($_GET['hal']=='petugas') {
          include "style/style_tabel.php";
        }
        elseif ($_GET['hal']=='tambah_petugas') {
          include "style/style2.php";
        }
        elseif ($_GET['hal']=='edit_petugas') {
          include "style/style2.php";
        }



        else
        {
          include "style/style1.php";
        }
    }else{
    include "style/style1.php";
    }
?>